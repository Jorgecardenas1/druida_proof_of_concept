
class MetaSurface:

    def __init__(self, size, grid_size, atom_grid, **kwargs  ):
        self.size = size
        self.grid_size = grid_size
        self.grid_atom=atom_grid

        pass

    def checkKwargArgument(self):
        pass
    


    def create(self):
        pass

    def checkGrid(self):
        pass


