global inputType
inputType=dict({
    'image' :'image',
    'vector' : 'vector'
})